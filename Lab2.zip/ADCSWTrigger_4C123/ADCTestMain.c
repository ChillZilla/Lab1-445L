// ADCTestMain.c
// Runs on TM4C123
// This program periodically samples ADC channel 0 and stores the
// result to a global variable that can be accessed with the JTAG
// debugger and viewed with the variable watch feature.
// Daniel Valvano
// September 5, 2015

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2015

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// center of X-ohm potentiometer connected to PE3/AIN0
// bottom of X-ohm potentiometer connected to ground
// top of X-ohm potentiometer connected to +3.3V 
#include <stdint.h>
#include "ADCSWTrigger.h"
#include "tm4c123gh6pm.h"
#include "ST7735.h"
#include "Timer1.h"
#include "fixed.h"
#include "PLL.h"

#define PF2             (*((volatile uint32_t *)0x40025010))
#define PF1             (*((volatile uint32_t *)0x40025008))
#define PF4             (*((volatile uint32_t *)0x40025040))
//gobals
uint32_t xMax;
uint32_t yMax;

void DelayWait10ms(uint32_t n);
void PortF_Init(void);

void Pause(void){
  while(PF4==0x00){ 
    DelayWait10ms(10);
  }
  while(PF4==0x10){
    DelayWait10ms(10);
  }
}

//global variables
uint32_t time[1000];
uint32_t adcValues[1000];
uint32_t timeJitter = 0;
int curPlace = 0;
int fullArray = 0;
uint32_t diffArray[999];

uint32_t validADC[1000];
uint32_t incValues[1000];
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode

volatile uint32_t ADCvalue;
// This debug function initializes Timer0A to request interrupts
// at a 100 Hz frequency.  It is similar to FreqMeasure.c.
void Timer0A_Init100HzInt(void){
  volatile uint32_t delay;
  DisableInterrupts();
  // **** general initialization ****
  SYSCTL_RCGCTIMER_R |= 0x01;      // activate timer0
  delay = SYSCTL_RCGCTIMER_R;      // allow time to finish activating
  TIMER0_CTL_R &= ~TIMER_CTL_TAEN; // disable timer0A during setup
  TIMER0_CFG_R = 0;                // configure for 32-bit timer mode
  // **** timer0A initialization ****
                                   // configure for periodic mode
  TIMER0_TAMR_R = TIMER_TAMR_TAMR_PERIOD;
  TIMER0_TAILR_R = 799999;         // start value for 100 Hz interrupts
  TIMER0_IMR_R |= TIMER_IMR_TATOIM;// enable timeout (rollover) interrupt
  TIMER0_ICR_R = TIMER_ICR_TATOCINT;// clear timer0A timeout flag
  TIMER0_CTL_R |= TIMER_CTL_TAEN;  // enable timer0A 32-b, periodic, interrupts
  // **** interrupt initialization ****
                                   // Timer0A=priority 2
  NVIC_PRI4_R = (NVIC_PRI4_R&0x00FFFFFF)|0x40000000; // top 3 bits
  NVIC_EN0_R = 1<<19;              // enable interrupt 19 in NVIC
}

void SysTick_Init(uint32_t period){long sr;
  sr = StartCritical();
  NVIC_ST_CTRL_R = 0;         // disable SysTick during setup
  NVIC_ST_RELOAD_R = period-1;// reload value
  NVIC_ST_CURRENT_R = 0;      // any write to current clears it
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x20000000; // priority 2
                              // enable SysTick with core clock and interrupts
  NVIC_ST_CTRL_R = 0x07;
  EndCritical(sr);
}

void Timer2_Init(void(*task)(void), unsigned long period){
  SYSCTL_RCGCTIMER_R |= 0x04;   // 0) activate timer2
  PeriodicTask = task;          // user function
  TIMER2_CTL_R = 0x00000000;    // 1) disable timer2A during setup
  TIMER2_CFG_R = 0x00000000;    // 2) configure for 32-bit mode
  TIMER2_TAMR_R = 0x00000002;   // 3) configure for periodic mode, default down-count settings
  TIMER2_TAILR_R = 7919;        // 4) reload value
  TIMER2_TAPR_R = 0;            // 5) bus clock resolution
  TIMER2_ICR_R = 0x00000001;    // 6) clear timer2A timeout flag
  TIMER2_IMR_R = 0x00000001;    // 7) arm timeout interrupt
  NVIC_PRI5_R = (NVIC_PRI5_R&0x00FFFFFF)|0x20000000; // 8) priority 1
// interrupts enabled in the main program after all devices initialized
// vector number 39, interrupt number 23
  NVIC_EN0_R = 1<<23;           // 9) enable IRQ 23 in NVIC
  //TIMER2_CTL_R = 0x00000001;    // 10) enable timer2A
}

void Timer2A_Handler(void){
  TIMER2_ICR_R = TIMER_ICR_TATOCINT;// acknowledge TIMER2A timeout
  (*PeriodicTask)();                // execute user task
}


int jitterReady = 0;

void adcArrayInit(void){
	for(int i = 0; i < 1000; i++){
		validADC[i] = 0xFFFFFFFF;
		incValues[i] = 0xFFFFFFFF;
	}
	return;
}

void Timer0A_Handler(void){
  TIMER0_ICR_R = TIMER_ICR_TATOCINT;    // acknowledge timer0A timeout
  PF2 ^= 0x04;                   // profile
  PF2 ^= 0x04;                   // profile
  ADCvalue = ADC0_InSeq3();
	if(curPlace >= 1000){
		//need to stop collection values, set a flag? --or just return.
		jitterReady = 1;
		return;
	}
	adcValues[curPlace] = ADCvalue; //get the reading from the ADC
	time[curPlace] = TIMER1_TAR_R; //holds the current times---but is decrementing
	curPlace = curPlace + 1; //keeps track of the places in the arrays
  PF2 ^= 0x04;                   // profile
}

void differenceTask(void){ //determines the time differences in the array and the jitter
	
	for(int i = 0; i < 999; i ++){//determine time differences
		diffArray[i] = (time[i] - time[i + 1]); //want to do first - second, must account for rollover
	}
	//determine time jitter
	uint32_t max = diffArray[0];
	uint32_t min = diffArray[0];
	for(int i = 1; i < 999; i ++){
	  if(diffArray[i] > max){	
	     max = diffArray[i];
			}
		else if(diffArray[i] < min){
			min = diffArray[i];
		}
	}		
	timeJitter = (max - min);
	return;
}

void plotPMF(char* title){
	
	for(int i = 0; i < 1000; i ++){
		
		for(int j = 0; j < 1000; j ++){
			
			if(adcValues[i] == validADC[j]){
				incValues[j] = incValues[j] + 1;
				break; //we found a validADC value, so move on to the next ADCValue in the array
			}
			else if(validADC[j] > 0x1000){
				validADC[j] = adcValues[i];
				incValues[j] = 1; 
 				
				break; //break out of this inner loop and go to the next outside ADC array value
			}
		}
	}
	uint32_t max = validADC[0];
	uint32_t min = validADC[0];
	uint32_t incMax = incValues[0];
	int incMin = 0;
	int count = 0;
	for(int i = 1; i < 1000; i ++){
		if(validADC[i] > 0x1000){
      count = i;       
			break;		
		}
		else if(max < validADC[i]){
       max = validADC[i];		
		}
		else if(min > validADC[i]){
		   min = validADC[i];
		}
		
		if(incMax < incValues[i]){
		   incMax = incValues[i];
			 
		}
		
	}
	
	ST7735_XYplotInit(title, min, max, incMin, incMax);
	ST7735_XYplot(count, validADC, incValues);
	
	return;
}

// Interrupt service routine
// Executed every 12.5ns*(period)
void SysTick_Handler(void){
  PF2 ^= 0x04;                // toggle PF2
  PF2 ^= 0x04;                // toggle PF2
 // Counts = Counts + 1;
  PF2 ^= 0x04;                // toggle PF2
}
uint32_t xvals[128];
uint32_t yvals[128];
void ST7735_Line(int32_t x1, int32_t x2, int32_t y1, int32_t y2){
	ST7735_FillRect(0, 32, 128, 128, ST7735_Color565(255, 165, 0));
	double rise = 0;
	double run = 0;
	int32_t minx = 0;
	int32_t miny = 0;

	rise = y2 - y1;
	run = x2 - x1;
	
	
	if( x1 > x2){
    
		
		minx = x2;
		miny = y2;
		yMax = y1;
		xMax = x1;
	}
	else{
		
		xMax = x2;
		yMax = y2;
		minx = x1;
		miny = y1;
		
	}
	
	double intercept = y1 - (rise/run)*(x1);
	xvals[0] = minx;
	yvals[0] = miny;
	uint32_t pts = 1;
	for(uint32_t i = minx + 1; i < xMax; i ++){

		uint32_t yVal = ((rise)*i)/run + intercept; //calculating the y value for the x = i
		
		xvals[pts] = i;
		yvals[pts] = yVal;
		pts ++;
		
	}
	xvals[pts] = xMax;
	yvals[pts] = yMax;
	
	ST7735_XYplot(pts, xvals, yvals);
	

}


int main(void){
	adcArrayInit();
  PLL_Init(Bus80MHz);                   // 80 MHz
  SYSCTL_RCGCGPIO_R |= 0x20;            // activate port F
  ADC0_InitSWTriggerSeq3_Ch9(0);         // allow time to finish activating
	SysTick_Init(7920);
  Timer0A_Init100HzInt();               // set up Timer0A for 100 Hz interrupts
  Timer1_Init(0, 0);
//	Timer2_Init(0,0);
//	Timer3_Init(0,0);
	/*GPIO_PORTF_DIR_R |= 0x06;             // make PF2, PF1 out (built-in LED)
  GPIO_PORTF_AFSEL_R &= ~0x06;          // disable alt funct on PF2, PF1
  GPIO_PORTF_DEN_R |= 0x06;             // enable digital I/O on PF2, PF1
                                        // configure PF2 as GPIO
  GPIO_PORTF_PCTL_R = (GPIO_PORTF_PCTL_R&0xFFFFF00F)+0x00000000;
  GPIO_PORTF_AMSEL_R = 0;               // disable analog functionality on PF*/
	PortF_Init();
  PF2 = 0;                      // turn off LED
  	

while(1){
	ST7735_XYplotInit("test", 0, 128, 0, 128);
	ST7735_Line(10, 128, 50, 10);
	Pause();
	EnableInterrupts();
	curPlace = 0;
	
  while(1){
//    PF1 ^= 0x02;  // toggles when running in main
		PF1 = (PF1*12345678)/1234567+0x02;  // this line causes jitter
		
		if(jitterReady == 1){
			DisableInterrupts(); //don't need to take any more samples.
			differenceTask();
			jitterReady = 0;
			//plot the pmf here
			plotPMF("ADC SAMPLING NONE");
     	Pause();
      break;
		}
		 
  }
	ADC0_InitSWTriggerSeq3_Ch9(4);
	curPlace = 0;
	EnableInterrupts();
	while(1){ //sampling with 4x
		  
			PF1 = (PF1*12345678)/1234567+0x02;  // this line causes jitter
		if(jitterReady == 1){
			DisableInterrupts(); //don't need to take any more samples.
			differenceTask();
			jitterReady = 0;
			//plot the pmf here
			plotPMF("ADC SAMPLING 4x");
			Pause();
      break;
     		
		}		
	}
	ADC0_InitSWTriggerSeq3_Ch9(16);
	curPlace = 0;
	EnableInterrupts();
	while(1){ //sampling with 16x
		
			PF1 = (PF1*12345678)/1234567+0x02;  // this line causes jitter
		if(jitterReady == 1){
			DisableInterrupts(); //don't need to take any more samples.
			differenceTask();
			jitterReady = 0;
			//plot the pmf here
			plotPMF("ADC SAMPLING 16x");
     	Pause();
     break;
		}
		
	}
	ADC0_InitSWTriggerSeq3_Ch9(64);
	curPlace = 0;
	EnableInterrupts();
	while(1){ //sampling with 64x
		
			PF1 = (PF1*12345678)/1234567+0x02;  // this line causes jitter
		if(jitterReady == 1){
			DisableInterrupts(); //don't need to take any more samples.
			differenceTask();
			jitterReady = 0;
			//plot the pmf here
			plotPMF("ADC SAMPLING 64x");
     	Pause();
     break;	
		}
				
	}
	ADC0_InitSWTriggerSeq3_Ch9(0);         // allow time to finish activating
 }
}

// PF4 is input
// Make PF2 an output, enable digital I/O, ensure alt. functions off
void PortF_Init(void){ 
  SYSCTL_RCGCGPIO_R |= 0x20;        // 1) activate clock for Port F
  while((SYSCTL_PRGPIO_R&0x20)==0){}; // allow time for clock to start
                                    // 2) no need to unlock PF2, PF4
  GPIO_PORTF_PCTL_R &= ~0x000F0F00; // 3) regular GPIO
  GPIO_PORTF_AMSEL_R &= ~0x16;      // 4) disable analog function on PF2, PF4
  GPIO_PORTF_PUR_R |= 0x10;         // 5) pullup for PF4
  GPIO_PORTF_DIR_R |= 0x06;         // 5) set direction to output
  GPIO_PORTF_AFSEL_R &= ~0x16;      // 6) regular port function
  GPIO_PORTF_DEN_R |= 0x16;         // 7) enable digital port
}
// Subroutine to wait 10 msec
// Inputs: None
// Outputs: None
// Notes: ...
void DelayWait10ms(uint32_t n){uint32_t volatile time;
  while(n){
    time = 727240*2/91;  // 10msec
    while(time){
	  	time--;
    }
    n--;
  }
}

