//Alarm changing functions call when setting alarms

void AlarmChange(int alarmNumber);

