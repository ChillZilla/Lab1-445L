#include "Button.h"
#include "AlarmChange.h"
#include "ClockChange.h"
//this is where all of our button functions reside

#define PB0   (*((volatile unsigned long *)0x40005400)) // move cursor bit
#define PB1   (*((volatile unsigned long *)0x40005404)) // up bit
#define PB2   (*((volatile unsigned long *)0x4000540C)) // down bit
#define PB3   (*((volatile unsigned long *)0x4000541C)) // Select bit
#define PE0   (*((volatile unsigned long *)0x40024400)) // snooze
#define PE3   (*((volatile unsigned long *)0x4002441C)) // off

int bottomCursorX = 0;

/****Check Button****/
/*
This function checks if any of the buttons have been pushed, if so it reacts accordingly
*/
void checkButton(void){

if(PB0 == 1){ //we need to move the cursor depending on it's position
  bottomCursorX += 32; //change the cursor position
}
else if(PB3 == 1){
  if(bottomCursorX == 16){
   //selecting time to manipulate
   TimeChange();
  }
  else if(bottomCursorX == 48){
   //modifying an alarm
   AlarmChange(48);
  }
  else if(bottomCursorX == 80){
    //modifying Alarm 2
	 AlarmChange(80);
  }
  else if(bottomCursorX == 112){
   // modifying Alarm 3
   AlarmChange(112);
  }
  else{ //greater than 112 -- off the screen, set it back to T
    bottomCursorX = 16;
  }
  
}
  
}



