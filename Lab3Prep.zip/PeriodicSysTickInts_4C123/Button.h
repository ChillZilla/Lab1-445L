
/* Button functionality*/


void checkButton(void);

