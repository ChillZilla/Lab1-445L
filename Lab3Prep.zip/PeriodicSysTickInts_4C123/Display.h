//Display.h functions
#include "ST7735.h"
void tabDisplay(int tab, int on);

void analogClock(int time);

void digitalClock(int time);

void cursorDisplay(int position);

void ST7735_Line(int x1, int x2, int y1, int y2);

