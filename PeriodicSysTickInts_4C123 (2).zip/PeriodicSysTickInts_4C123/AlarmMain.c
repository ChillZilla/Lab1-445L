
//main function that runs everything/
#include "Button.h"
#include "AlarmChange.h"
#include "ClockChange.h"
#include "PLL.h"
#include "Display.h"
#include "ST7735.h"


void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode 

#define PE5   (*((volatile unsigned long *)0x4002447C)) // sounds 
//implement deboucing*****

//W timer--wide timer 64 bit timer (look at this)
//PWM -- pulse width modulation

void EdgeTriggered_Buttons(void){
	DisableInterrupts();
	SYSCTL_RCGCGPIO_R |= 0x42; //activate Port B and Port E for button triggering
	GPIO_PORTB_DIR_R &= ~0xF; //Make PortB pins 0-3 inputs
	GPIO_PORTB_DEN_R |= 0xF; //enable digital IO on PortB0-3
	GPIO_PORTB_IS_R &= ~0xF; //PortB 0-3 is edge sensitive
	GPIO_PORTB_IBE_R &= ~0xF; //PB0-3 is not both edge sensitive
	GPIO_PORTB_IEV_R |= 0xF; //Rising edge events (when the button goes from off to on
	GPIO_PORTB_ICR_R = 0xF; //clear the flags for PB0-3
	GPIO_PORTB_IM_R |= 0xF;
	NVIC_PRI0_R = (NVIC_PRI0_R&0xF00FFFFF)|0x04000000; //PORTB priority 2
	
	GPIO_PORTE_DIR_R &= ~0x5; //Make PortB pins 0-3 inputs
	GPIO_PORTE_DEN_R |= 0x5; //enable digital IO on PortB0-3
	GPIO_PORTE_IS_R &= ~0x5; //PortB 0-3 is edge sensitive
	GPIO_PORTE_IBE_R &= ~0x5; //PB0-3 is not both edge sensitive
	GPIO_PORTE_IEV_R |= 0x5; //Rising edge events (when the button goes from off to on
	GPIO_PORTE_ICR_R = 0x5; //clear the flags for PB0-3
	GPIO_PORTE_IM_R |= 0x5;
	
  NVIC_PRI0_R = (NVIC_PRI0_R&0xFFFFFF00) | 0x00000040; //
		
}

void PortB_Init(void) {
  while((SYSCTL_PRGPIO_R&0x02) == 0){}
  GPIO_PORTB_PCTL_R &= 0x0000FFFF;      // PCTL GPIO on PB3-PB0
  GPIO_PORTB_AMSEL_R &= ~0x0F;          // disable analog on PB3-PB0
  GPIO_PORTB_DIR_R &= ~0x0F;            // direction PB3-PB0 input
  GPIO_PORTB_AFSEL_R &= ~0x0F;          // PB3-PB0 regular port function
  GPIO_PORTB_DEN_R |= 0x0F;             // enable PB3-PB0 digital port
}

void PortE_Init(void) {
  while((SYSCTL_PRGPIO_R&0x10) == 0){}
  GPIO_PORTB_PCTL_R &= 0x0000F00F;      // PCTL GPIO on PE0, PE3
  GPIO_PORTB_AMSEL_R &= ~0x09;          // disable analog on PE0, PE3
  GPIO_PORTB_DIR_R &= ~0x09;            // direction PE0, PE3 input
  GPIO_PORTB_AFSEL_R &= ~0x09;          // PE0, PE3 regular port function
  GPIO_PORTB_DEN_R |= 0x09;             // enable PE0, PE3 digital port
}

void SysTick_Init(uint32_t period){long sr;
  sr = StartCritical();
  NVIC_ST_CTRL_R = 0;         // disable SysTick during setup
  NVIC_ST_RELOAD_R = period-1;// reload value
  NVIC_ST_CURRENT_R = 0;      // any write to current clears it
  NVIC_SYS_PRI3_R = (NVIC_SYS_PRI3_R&0x00FFFFFF)|0x40000000; // priority 2
                              // enable SysTick with core clock and interrupts
  NVIC_ST_CTRL_R = 0x07;
  EndCritical(sr);
}


void PortF_Init(void) {
  while((SYSCTL_PRGPIO_R&0x20)==0){};
  GPIO_PORTF_PCTL_R &= ~0x000F0F00;     // regular GPIO
  GPIO_PORTF_AMSEL_R &= ~0x04;          // disable analog function on PF2
  GPIO_PORTF_DIR_R |= 0x04;             // set direction to output
  GPIO_PORTF_AFSEL_R &= ~0x04;          // regular port function
  GPIO_PORTF_DEN_R |= 0x04;             // enable digital port
}

void GPIOPortB_Handler(void) {
  if(GPIO_PORTB_RIS_R&0x01) {
    GPIO_PORTB_ICR_R = 0x01;
    PB0_Pushed = 1;
  }
  if(GPIO_PORTB_RIS_R&0x02) {
    GPIO_PORTB_ICR_R = 0x02;
    PB1_Pushed = 1;
  }
  if(GPIO_PORTB_RIS_R&0x04) {
    GPIO_PORTB_ICR_R = 0x04;
    PB2_Pushed = 1;
  }
  if(GPIO_PORTB_RIS_R&0x08) {
    GPIO_PORTB_ICR_R = 0x08;
    PB3_Pushed = 1;
  }
 
}

void GPIOPORTE_Handler(void){
	 if(GPIO_PORTE_RIS_R&0x01) {
    GPIO_PORTB_ICR_R = 0x10;
    PE0_Pushed = 1;
  }
  if(GPIO_PORTE_RIS_R&0x04) {
    GPIO_PORTB_ICR_R = 0x20;
    PE3_Pushed = 1;
  }
}

int main(void) {
	
  PLL_Init(80000000);
  SYSCTL_RCGCGPIO_R |= 0x32;
	ST7735_InitR(INITR_REDTAB);
//  SysTick_Init(800000000);              // interrupts every 1s
  PortF_Init();
	ST7735_FillScreen(ST7735_BLACK);
  EdgeTriggered_Buttons();
	currentTime = 0x0C000;
	CursorX = 0;
  CursorY = 10;
	
	EnableInterrupts();
  while (1) {
/*    checkButton(); //sets AlarmTab and TimeTab flags and also increments cursor position
		if((PB1_Pushed || PB2_Pushed) && CursorY == 9){ //increment or decrement current time
       if(Alarm0_Sel == 1){
           AlarmChange(0); 
				}
       else if(Alarm1_Sel == 1){
           AlarmChange(1);
			 }  	
			 else if(Alarm2_Sel == 1){
			     AlarmChange(2);
			 }
			 else if(Clock_Sel == 1){
				 TimeChange();
			 }
			 //update the display
			
		}	
		//updates the analog and digital display
  //  DisplayClock();		
		*/
		analogClock(currentTime);
		
  }
}


uint32_t countMn = 0;

void SysTick_Handler(void) {
  // when 1 minute passes
  if (countMn == 60) {
    if ((currentTime & 0x000F0) == 0x00090) {         // XX:X9 - clear the 9
      currentTime &= 0x000F0;
      if ((currentTime & 0x00F00) == 0x00500) {       // XX:59 - clear the 9, 5 (XX:00)
        currentTime &= 0x00F00;
        if ((currentTime & 0x0F000) == 0x0C000) {     // 12:59 - clear the 9, 5, 12 (00:00)
          currentTime &= 0x0F000;
        }
        if ((currentTime & 0x0F000) == 0x0B000) {     // 11:59 - toggle AM/PM
          if ((currentTime & 0x0000F) == 0x00000) {
            currentTime += 0x00001;
          } else {
            currentTime -= 0x00001;
          }
        }
        currentTime += 0x01000;                       // 00:00 -> 01:00
      } else {                                        // XX:X9 -> XX:(X+1)0
        currentTime += 0x00100;
      }
    } else {                                          // XX:XX -> XX:X(X+1)
      currentTime += 0x00010;
    }
  
    countMn = 0;
  } else {
    countMn += 1;
  }
  
  if (((currentTime == alarm0) || (currentTime == alarm1) || (currentTime == alarm2)) && (countMn < 12)) {
    PE5 ^= 1;
  }
}

