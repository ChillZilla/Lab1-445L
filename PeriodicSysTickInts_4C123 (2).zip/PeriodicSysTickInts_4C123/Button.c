#include "Button.h"
#include "AlarmChange.h"
#include "ClockChange.h"
//this is where all of our button functions reside

#define PB0   (*((volatile unsigned long *)0x40005400)) // move cursor bit
#define PB1   (*((volatile unsigned long *)0x40005404)) // up bit
#define PB2   (*((volatile unsigned long *)0x4000540C)) // down bit
#define PB3   (*((volatile unsigned long *)0x4000541C)) // Select bit
#define PE0   (*((volatile unsigned long *)0x40024400)) // snooze
#define PE3   (*((volatile unsigned long *)0x4002441C)) // off

int PB0_Pushed;
int PB1_Pushed;
int PB2_Pushed;
int PB3_Pushed;
int PE0_Pushed;
int PE3_Pushed;

int CursorX;
int CursorY;
int exitTimeChange;

int AlarmTab;
int Alarm1Tab;
int Alarm2Tab;
int TimeTab;

/****Check Button****/
/*
This function checks if any of the buttons have been pushed, if so it reacts accordingly
*/

void checkButton(void){

  if(PB0_Pushed == 1){ //we need to move the cursor depending on it's position
    if(CursorY == 9){
			CursorX += 32; //change the cursor position
		}
		else if(CursorY == 149){
		  CursorX += 8;
		}
  }
  else if(PB3_Pushed == 1){ // a select choice was made -- need to determine where the cursor is
		if(CursorY == 149){
			//we are at the bottom of the screen - just selected an alarm or time change
			if(CursorX == 48){ //selecting time tab
				TimeTab = 1;
			}
			else if(CursorX == 52){ //selecting alarm tab
				AlarmTab = 1;
			}
			else if(CursorX == 60){ //selecting alarm tab
			  Alarm1Tab = 1;
			}
			else if(CursorX == 68){ //selecting alarm tab
				Alarm2Tab = 1;
			}
			CursorY = 9;
		}
		else if(CursorY == 9){ //changing time up above
		  exitTimeChange = 1; //set flag to save the current time and get out
			//Does exit time change matter? If I just make all of these zero, then we can output the correct time, yes? 
			//Try this first, if this doesn't work, use the exit flag to change these to zero after we update their display
			TimeTab = 0;
			AlarmTab = 0;
			Alarm1Tab = 0;
			Alarm2Tab = 0;
			
		  CursorY = 149;
			CursorX = 48;
		}
  
  }
  
}



