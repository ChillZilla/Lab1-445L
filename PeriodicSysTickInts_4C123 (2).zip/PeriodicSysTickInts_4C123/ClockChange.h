

//handles the changing of the time
//Called when we are setting the clock time 


void TimeChange(void);


