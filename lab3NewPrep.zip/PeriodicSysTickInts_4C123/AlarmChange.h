//Alarm changing functions call when setting alarms

void AlarmChange(int alarmNumber);

extern int alarm0;
extern int alarm1;
extern int alarm2;