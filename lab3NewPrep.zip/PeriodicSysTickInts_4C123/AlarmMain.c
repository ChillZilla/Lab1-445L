
//main function that runs everything/
#include "Button.h"
#include "AlarmChange.h"
#include "ClockChange.h"
#include "PLL.h"
#include "Display.h"
#include "ST7735.h"
#include "SysTickInts.h"
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode 


void EdgeTriggered_Buttons(void){
	SYSCTL_RCGCGPIO_R |= 0x42; //activate Port B and Port E for button triggering
	GPIO_PORTB_DIR_R &= ~0xF; //Make PortB pins 0-3 inputs
	GPIO_PORTB_DEN_R |= 0xF; //enable digital IO on PortB0-3
	GPIO_PORTB_IS_R &= ~0xF; //PortB 0-3 is edge sensitive
	GPIO_PORTB_IBE_R &= ~0xF; //PB0-3 is not both edge sensitive
	GPIO_PORTB_IEV_R |= 0xF; //Rising edge events (when the button goes from off to on
	GPIO_PORTB_ICR_R = 0xF; //clear the flags for PB0-3
	GPIO_PORTB_IM_R |= 0xF;
	NVIC_PRI0_R = (NVIC_PRI0_R&0xF00FFFFF)|0x04000000; //PORTB priority 2
	
	GPIO_PORTE_DIR_R &= ~0x5; //Make PortB pins 0-3 inputs
	GPIO_PORTE_DEN_R |= 0x5; //enable digital IO on PortB0-3
	GPIO_PORTE_IS_R &= ~0x5; //PortB 0-3 is edge sensitive
	GPIO_PORTE_IBE_R &= ~0x5; //PB0-3 is not both edge sensitive
	GPIO_PORTE_IEV_R |= 0x5; //Rising edge events (when the button goes from off to on
	GPIO_PORTE_ICR_R = 0x5; //clear the flags for PB0-3
	GPIO_PORTE_IM_R |= 0x5;
	
  NVIC_PRI0_R = (NVIC_PRI0_R&0xFFFFFF00) | 0x00000040; //
		
}

void PortB_Init(void) {
  while((SYSCTL_PRGPIO_R&0x02) == 0){}
  GPIO_PORTB_PCTL_R &= 0x0000FFFF;      // PCTL GPIO on PB3-PB0
  GPIO_PORTB_AMSEL_R &= ~0x0F;          // disable analog on PB3-PB0
  GPIO_PORTB_DIR_R &= ~0x0F;            // direction PB3-PB0 input
  GPIO_PORTB_AFSEL_R &= ~0x0F;          // PB3-PB0 regular port function
  GPIO_PORTB_DEN_R |= 0x0F;             // enable PB3-PB0 digital port
}

void PortE_Init(void) {
  while((SYSCTL_PRGPIO_R&0x10) == 0){}
  GPIO_PORTB_PCTL_R &= 0x0000F00F;      // PCTL GPIO on PE0, PE3
  GPIO_PORTB_AMSEL_R &= ~0x09;          // disable analog on PE0, PE3
  GPIO_PORTB_DIR_R &= ~0x09;            // direction PE0, PE3 input
  GPIO_PORTB_AFSEL_R &= ~0x09;          // PE0, PE3 regular port function
  GPIO_PORTB_DEN_R |= 0x09;             // enable PE0, PE3 digital port
}

void PortF_Init(void) {
  while((SYSCTL_PRGPIO_R&0x20)==0){};
  GPIO_PORTF_PCTL_R &= ~0x000F0F00;     // regular GPIO
  GPIO_PORTF_AMSEL_R &= ~0x04;          // disable analog function on PF2
  GPIO_PORTF_DIR_R |= 0x04;             // set direction to output
  GPIO_PORTF_AFSEL_R &= ~0x04;          // regular port function
  GPIO_PORTF_DEN_R |= 0x04;             // enable digital port
}

int main1 (void) {
  PLL_Init(80000000);
  SYSCTL_RCGCGPIO_R |= 0x32;
  SysTick_Init(800000000);              // interrupts every 1s
  PortF_Init();
  PortB_Init();
  PortE_Init();
	CursorX = 0;
  CursorY = 10;
  while (1) {
    checkButton(); //sets AlarmTab and TimeTab flags and also increments cursor position
		if((PB1_Pushed || PB2_Pushed) && CursorY == 9){ //increment or decrement current time
       if(Alarm0_Sel == 1){
           AlarmChange(0); 
				}
       else if(Alarm1_Sel == 1){
           AlarmChange(1);
			 }  	
			 else if(Alarm2_Sel == 1){
			     AlarmChange(2);
			 }
			 else if(Clock_Sel == 1){
				 TimeChange();
			 }
			 //update the display
			
		}	
    DisplayClock();		
		
  }
}


uint32_t countMn = 0;

void SysTick_Handler(void) {
  // when 1 minute passes
  if (countMn == 60) {
    if ((currentTime & 0x000F0) == 0x00090) {         // XX:X9 - clear the 9
      currentTime &= 0x000F0;
      if ((currentTime & 0x00F00) == 0x00500) {       // XX:59 - clear the 9, 5 (XX:00)
        currentTime &= 0x00F00;
        if ((currentTime & 0x0F000) == 0x0C000) {     // 12:59 - clear the 9, 5, 12 (00:00)
          currentTime &= 0x0F000;
        }
        if ((currentTime & 0x0F000) == 0x0B000) {     // 11:59 - toggle AM/PM
          if ((currentTime & 0x0000F) == 0x00000) {
            currentTime += 0x00001;
          } else {
            currentTime -= 0x00001;
          }
        }
        currentTime += 0x01000;                       // 00:00 -> 01:00
      } else {                                        // XX:X9 -> XX:(X+1)0
        currentTime += 0x00100;
      }
    } else {                                          // XX:XX -> XX:X(X+1)
      currentTime += 0x00010;
    }
    
    digitalClock(currentTime);
    analogClock(currentTime);
    
    countMn = 0;
  } else {
    countMn += 1;
  }
}

