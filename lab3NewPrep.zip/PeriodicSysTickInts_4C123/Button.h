
/* Button functionality*/
extern int PB0_Pushed;
extern int PB1_Pushed;
extern int PB2_Pushed;
extern int PB3_Pushed;
extern int PE0_Pushed;
extern int PE3_Pushed;
extern int CursorX;
extern int CursorY;
extern int exitTimeChange;

extern int AlarmTab;
extern int Alarm1Tab;
extern int Alarm2Tab;
extern int TimeTab;

void checkButton(void);

