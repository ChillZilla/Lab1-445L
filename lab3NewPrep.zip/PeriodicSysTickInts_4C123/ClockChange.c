/*

This file contains the function to change the current time of the clock.

*/

#include "Button.h"

#define PB0   (*((volatile unsigned long *)0x40005400)) // move cursor bit
#define PB1   (*((volatile unsigned long *)0x40005404)) // up bit
#define PB2   (*((volatile unsigned long *)0x4000540C)) // down bit
#define PB3   (*((volatile unsigned long *)0x4000541C)) // Select bit
#define PE0   (*((volatile unsigned long *)0x40024400)) // snooze
#define PE3   (*((volatile unsigned long *)0x4002441C)) // off

/****** TimeChange() ******/
int currentClockTime;
int topCursorX = 14;

void TimeChange(void){
	//want to modify the time we see on the clock.
	int localTime = currentClockTime&0xFFFFF;
	int increment = 0;
	int first = localTime & 0xFF000;
	 int second = localTime & 0x00F00;
	 int third = localTime & 0x000F0;
	 int AMPM = localTime & 0x0000F;

	 if(PB1_Pushed == 1){ //increment current place
			
			switch(increment){
				
				case 0:
					//check first number
				  
				  if(first == 0x0C000){ //moving into double digits
					   localTime = localTime & 0x01FFF; //write back a 1 to rollover to twelve
					}
					else {
						localTime = localTime + 0x01000;
					}
					break;
				case 1: //need to move the cursor to the next number 
					topCursorX = 64;
				  //Display the cursor change;
				  
				  if(second == 0x00500){ //at the max value you can set 12:*0
						  localTime = localTime & 0xFF0FF;
					  }
					else{
						localTime = localTime + 0x00100;
					}
					break;
				case 2: //updating the last digit in the time
					topCursorX = 84; //middle of the thing
				  //Display the cursor changes
				 
				  if(third == 0x00090){
					   localTime = localTime & 0xFFF0F;
					}
					else {
					  localTime = localTime + 0x00010;
					}
					break;
				case 3: //modify AM or PM
					topCursorX = 104;
				 
				  if(AMPM == 0x0){ //AM = 0, PM = 1
						localTime = localTime + 0x01; //change to PM
					}
					else{ //change to AM
					  localTime = localTime & 0xFFFF0;
					}
					break;
				}	
		}
		else if(PB2_Pushed == 1){ //decrement time
			switch(increment){
				
				case 0:
					//check first number
				  
				  if(first == 0x01000){ //moving into double digits
					   localTime = localTime & 0x00FFF; //write back rollover to 12
						 localTime = localTime & 0x0CFFF;
					}
					else {
						localTime = localTime - 0x01000;
					}
					break;
				case 1: //need to move the cursor to the next number 
					topCursorX = 64;
				  //Display the cursor change;
				  
				  if(second == 0x00000){ //at the max value you can set 12:*0
						  localTime = localTime & 0xFF0FF;
						  localTime = localTime + 0x00500; //set to 5, because we were at 0
					  }
					else{
						localTime = localTime - 0x00100; //otherwise, just decrement 1
					}
					break;
				case 2: //updating the last digit in the time
					topCursorX = 84; //middle of the thing
				  //Display the cursor changes
				
				  if(third == 0x00000){ //if equal to 0, rollover to 9
					   localTime = localTime & 0xFFF0F;
						 localTime = localTime + 0x00090;
					}
					else {
					  localTime = localTime - 0x00010;
					}
					break;
				case 3: //modify AM or PM
					topCursorX = 104;
				 
				  if(AMPM == 0x0){ //AM = 0, PM = 1
						localTime = localTime + 0x01; //change to PM
					}
					else{ //change to AM
					  localTime = localTime & 0xFFFF0;
					}
					break;
		}
	}
		//continue on
	

}

