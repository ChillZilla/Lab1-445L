//Display.h functions
#include "ST7735.h"

extern int Alarm0_Sel;
extern int Alarm1_Sel;
extern int Alarm2_Sel;
extern int Clock_Sel;

void tabDisplay(int tab, int on);

void analogClock(int time);

void digitalClock(int time);

void cursorDisplay(int position);

void ST7735_Line(int x1, int x2, int y1, int y2);

extern int currentTime;
